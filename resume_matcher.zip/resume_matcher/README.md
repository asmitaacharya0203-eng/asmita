# AI Based Resume Matching Utility - Finance Industry

Reads resumes (PDF / TXT / DOCX), extracts finance skills, compares them with a job requirement,
ranks the candidates and displays the shortlist.

## Folder contents
| File | Purpose |
|---|---|
| `app.py` | **Main script** - Streamlit user interface |
| `resume_parser.py` | Reads PDF/TXT/DOCX, extracts name, contact, education, experience, certifications |
| `skills_db.py` | Finance skills taxonomy (~100 skills, 16 certifications) + extraction logic |
| `matcher.py` | Scoring, ranking and shortlisting engine (TF-IDF cosine similarity + rules) |
| `cli.py` | Optional command-line version |
| `generate_sample_resumes.py` | Creates 18 synthetic resumes in `resumes/` (already generated) |
| `data/job_roles.csv` | Job requirements master data (7 finance roles) - edit / add rows freely |
| `resumes/` | Sample resumes (PDF + TXT). Replace with your own or point the app to any folder |
| `output/` | Shortlists saved from the app (Excel + CSV) |

## How to run
```
pip install -r requirements.txt
streamlit run app.py
```
1. Pick a finance role (or create a custom requirement and paste a JD).
2. Choose the resume folder (default `resumes/`) or upload files.
3. Click **Run matching**.

Command-line alternative:
```
python cli.py --list-roles
python cli.py --role FIN001 --top 5 --export
python cli.py --role "Credit Risk Analyst" --folder "D:/HR/CVs"
```

## Adding a new job role
Add a row to `data/job_roles.csv`. Skills are separated by `;` and must use the names in `skills_db.py`
(e.g. `Financial Modelling;DCF Valuation`). `min_education_level`: 1=12th, 2=Diploma, 3=Bachelor's, 4=Master's/MBA/CA/CFA, 5=PhD.

## Adding new skills
Add the skill and its spelling variants (aliases) to `SKILLS` in `skills_db.py`.

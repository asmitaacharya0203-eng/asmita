"""
cli.py
------
Command-line version of the Resume Matching Utility (no browser needed).

Examples
    python cli.py --list-roles
    python cli.py --role FIN001
    python cli.py --role "Credit Risk Analyst" --folder "D:/HR/CVs" --top 5 --export
"""

import argparse
from pathlib import Path

import pandas as pd

import matcher
import resume_parser

BASE_DIR = Path(__file__).parent


def main():
    ap = argparse.ArgumentParser(description="Rank resumes against a finance job requirement")
    ap.add_argument("--role", default="FIN001", help="role_id or (part of) the job title from data/job_roles.csv")
    ap.add_argument("--folder", default=str(BASE_DIR / "resumes"), help="folder containing resumes (PDF/TXT/DOCX)")
    ap.add_argument("--top", type=int, default=5, help="maximum number of candidates to shortlist")
    ap.add_argument("--threshold", type=float, default=60, help="minimum match score to shortlist (0-100)")
    ap.add_argument("--min-must", type=float, default=0.5, help="minimum share of must-have skills (0-1)")
    ap.add_argument("--list-roles", action="store_true", help="show the available job roles and exit")
    ap.add_argument("--export", action="store_true", help="save the shortlist to ./output as Excel + CSV")
    args = ap.parse_args()

    jobs = matcher.load_job_roles(BASE_DIR / "data" / "job_roles.csv")
    roles_csv = pd.read_csv(BASE_DIR / "data" / "job_roles.csv")

    if args.list_roles:
        print(roles_csv[["role_id", "title", "department", "location"]].to_string(index=False))
        return

    key = args.role.lower()
    idx = next((i for i, r in roles_csv.iterrows() if key == r["role_id"].lower() or key in r["title"].lower()), None)
    if idx is None:
        raise SystemExit(f"No job role matches '{args.role}'. Use --list-roles to see the options.")
    job = jobs[idx]

    candidates, errors = resume_parser.load_resumes_from_folder(args.folder)
    print(f"\nJob: {job.title}   |   resumes read: {len(candidates)}   |   unreadable: {len(errors)}")
    for name, err in errors:
        print(f"  ! {name}: {err}")
    if not candidates:
        return

    results = matcher.rank_candidates(candidates, job, shortlist_threshold=args.threshold,
                                      top_n=args.top, min_must_coverage=args.min_must)
    df = matcher.results_to_dataframe(results)
    pd.set_option("display.width", 220)
    pd.set_option("display.max_colwidth", 60)

    print("\n=== SHORTLISTED CANDIDATES ===")
    short = df[df["Decision"] == "Shortlisted"]
    if short.empty:
        print("None - try lowering --threshold or --min-must")
    else:
        print(short[["Rank", "Candidate", "Match Score", "Must-have Skills", "Experience (yrs)", "Email"]].to_string(index=False))

    print("\n=== FULL RANKING ===")
    print(df[["Rank", "Candidate", "Match Score", "Decision", "Missing Must-haves"]].to_string(index=False))

    if args.export:
        path = matcher.export_shortlist(results, BASE_DIR / "output", job.title)
        print(f"\nShortlist saved to {path}")


if __name__ == "__main__":
    main()

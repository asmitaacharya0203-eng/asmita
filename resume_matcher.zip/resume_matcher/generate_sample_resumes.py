"""
generate_sample_resumes.py
--------------------------
Creates 18 synthetic (fictional) finance-industry resumes in ./resumes  -  a mix of .txt and .pdf files with
slightly different layouts, so the parser is exercised on realistic variety.

Run once:   python generate_sample_resumes.py
(All names, companies and contact details are made up.)
"""

import re
from datetime import date
from pathlib import Path

OUT = Path(__file__).parent / "resumes"

# The sample data below was written as if "today" were 2024. All years in dates / education lines are shifted
# forward so the resumes stay realistic whenever the generator is run.
YEAR_SHIFT = date.today().year - 2024


def _shift(text):
    return re.sub(r"\b(19|20)\d{2}\b", lambda m: str(int(m.group(0)) + YEAR_SHIFT), text)

# (name, city, style, summary, jobs[(title, company, dates, [bullets])], education[], skills, certs[], as_pdf)
CANDIDATES = [
    ("Priya Nair", "Pune", "standard",
     "Finance professional with 5 years of experience in FP&A for manufacturing and technology businesses.",
     [("Senior Financial Analyst", "Zenith Industries Ltd", "Jul 2021 - Present",
       ["Own the annual budgeting and rolling forecast for a Rs 900 Cr business unit using advanced Excel and financial modelling",
        "Prepare monthly variance analysis (budget vs actual) and MIS reports for the CFO and business heads",
        "Built scenario and sensitivity analysis models that supported two capex decisions",
        "Automated MIS dashboards in Power BI, cutting reporting time by 40%"]),
      ("Financial Analyst", "Orion Components Pvt Ltd", "Jun 2019 - Jun 2021",
       ["Financial statement analysis and ratio analysis of key customers and vendors",
        "Worked in SAP FICO for month-end reporting; strong communication with plant finance teams"])],
     ["MBA (Finance), Symbiosis Institute of Business Management, 2019", "B.Com, University of Pune, 2017"],
     "Financial Modelling, Budgeting, Forecasting, Variance Analysis, FP&A, Advanced Excel, Power BI, SAP, SQL, MIS Reporting",
     ["CFA Level II candidate"], False),

    ("Rahul Mehta", "Mumbai", "standard",
     "Investment banking analyst with 3 years of experience across M&A and capital raising mandates.",
     [("Analyst - Investment Banking", "Meridian Capital Advisors", "Aug 2022 - Present",
       ["Built DCF, LBO and trading comps models for 8 sell-side and buy-side M&A transactions",
        "Prepared pitch books, teasers and information memoranda (CIM) for mid-market clients",
        "Performed comparable company analysis and precedent transactions using Capital IQ and Bloomberg",
        "Supported due diligence and managed data rooms; PowerPoint and Excel power user"]),
      ("Summer Intern - Investment Banking", "Northbridge Securities", "May 2021 - Jul 2021",
       ["Industry research and valuation support for an IPO mandate in equity capital markets"])],
     ["MBA (Finance), SP Jain Institute of Management, 2022", "B.Com (Hons), Mumbai University, 2020"],
     "Financial Modelling, DCF, LBO, M&A, Comparable Company Analysis, Pitch Books, Capital IQ, Bloomberg, Advanced Excel, PowerPoint",
     ["CFA Level I passed"], True),

    ("Ananya Iyer", "Bengaluru", "alt",
     "Equity research analyst covering the banking and NBFC sector for a domestic institutional brokerage.",
     [("Research Analyst - BFSI", "Sterling Equities Research", "04/2020 - Present",
       ["Cover 14 banks and NBFCs; maintain earnings models and publish initiation and update reports with target prices",
        "Fundamental analysis and valuation using DCF, P/B and relative valuation",
        "Financial statement analysis and ratio analysis of asset quality and net interest margin trends",
        "Present research views to institutional clients; use Bloomberg, Capital IQ and Python for data analysis"]),
      ("Associate", "Sterling Equities Research", "07/2018 - 03/2020",
       ["Supported senior analysts with equity research, company visits and financial modelling"])],
     ["MBA Finance, IIM Kozhikode, 2018", "B.Com, Christ University, 2016"],
     "Equity Research, Fundamental Analysis, Valuation, Financial Modelling, Bloomberg, Capital IQ, Python, Presentation Skills, Communication",
     ["CFA Charterholder", "NISM Series XV (Research Analyst)"], True),

    ("Vikram Singh", "Mumbai", "standard",
     "Credit risk professional with 6+ years experience in corporate credit risk, Basel compliance and portfolio monitoring.",
     [("Manager - Credit Risk", "Apex Bank Ltd", "Jan 2020 - Present",
       ["Credit analysis and credit appraisal of corporate borrowers (Rs 50 - 500 Cr exposure), preparing credit memos",
        "Financial statement analysis and ratio analysis to derive internal credit rating",
        "Ran stress testing and expected credit loss (ECL) models under Basel III and RBI guidelines",
        "Built SQL and Python reports for portfolio monitoring and early warning signals; regulatory reporting to RBI"]),
      ("Credit Analyst", "Apex Bank Ltd", "Jun 2017 - Dec 2019",
       ["Loan underwriting support and risk assessment for mid-corporate clients"])],
     ["MBA (Finance), XLRI Jamshedpur, 2017", "B.Com, Delhi University, 2015"],
     "Credit Risk, Credit Analysis, Risk Management, Basel III, Stress Testing, Ratio Analysis, Financial Statement Analysis, SQL, Python, Regulatory Compliance",
     ["FRM Part II"], False),

    ("Sneha Kulkarni", "Pune", "standard",
     "Chartered Accountant and internal auditor with 5 years of experience in risk based audit and controls testing.",
     [("Senior Associate - Internal Audit", "Crestline Assurance LLP", "Sep 2021 - Present",
       ["Planned and executed risk based internal audits across procure-to-pay and record-to-report processes",
        "SOX and ICFR controls testing, walkthroughs and documentation of internal controls",
        "Performed reconciliations review and accounting checks under Ind AS and IFRS; reported findings to the audit committee",
        "Used data analysis (Excel, SQL) for full-population testing; strong communication with process owners"]),
      ("Audit Executive", "Crestline Assurance LLP", "Jul 2019 - Aug 2021",
       ["Statutory audit assistance, risk assessment and regulatory compliance checks"])],
     ["Chartered Accountant (ICAI), 2019", "B.Com, Fergusson College, 2016"],
     "Internal Audit, SOX, Internal Controls, Risk Management, Accounting, Reconciliation, Ind AS, IFRS, Advanced Excel, SQL, Communication",
     ["Chartered Accountant (ICAI)", "CISA"], True),

    ("Arjun Deshmukh", "Mumbai", "standard",
     "Portfolio manager with 12 years of experience managing multi-asset portfolios for HNI and institutional clients.",
     [("Senior Portfolio Manager", "Halcyon Asset Management", "Feb 2017 - Present",
       ["Manage Rs 2,400 Cr in equity and fixed income portfolios; asset allocation, portfolio construction and risk management",
        "Fundamental analysis and stock selection with detailed earnings models; use of derivatives for hedging",
        "Lead a team of 4 analysts; present portfolio reviews to the investment committee and clients (stakeholder management)",
        "Bloomberg Terminal and Python used for performance attribution"]),
      ("Fund Manager - Mutual Funds", "Ridgeway Mutual Fund", "Jun 2012 - Jan 2017",
       ["Asset management and fund management for open-ended equity schemes; wealth management client presentations"])],
     ["MBA (Finance), IIM Ahmedabad, 2012", "B.Com, St. Xavier's College, 2010"],
     "Portfolio Management, Asset Management, Fundamental Analysis, Fixed Income, Derivatives, Risk Management, Stakeholder Management, Leadership, Bloomberg, Python",
     ["CFA Charterholder", "CFP", "NISM Series VIII"], False),

    ("Meera Joshi", "Pune", "alt",
     "Accounts executive with 3 years of experience in bookkeeping, month-end closing and GST compliance.",
     [("Accounts Executive", "Vaanya Textiles Pvt Ltd", "Aug 2021 - Present",
       ["Handle general ledger, journal entries and bank reconciliation in Tally Prime and SAP",
        "Month-end close and preparation of financial statements as per Ind AS",
        "Prepare and file GST returns (GSTR-1, GSTR-3B) and TDS returns; accounts payable and receivable",
        "Support statutory audit and tax audit; attention to detail and accuracy"]),
      ("Accounts Assistant", "Kalyan & Co Chartered Accountants", "Jul 2020 - Jul 2021",
       ["Bookkeeping, GST filing and reconciliation for 25 SME clients"])],
     ["M.Com (Accountancy), Savitribai Phule Pune University, 2020", "B.Com, Modern College Pune, 2018"],
     "Accounting, Tally, SAP, GST, Taxation, TDS, Reconciliation, Month-end close, Advanced Excel, Accounts Payable, Accounts Receivable",
     ["Pursuing CA Inter"], False),

    ("Karan Malhotra", "Pune", "standard",
     "MBA Finance student seeking an entry-level role in investment banking or equity research.",
     [("Summer Intern - Equity Research", "Sterling Equities Research", "Apr 2024 - Jun 2024",
       ["Built a DCF valuation model for a listed consumer company and wrote a 12-page initiation report",
        "Financial statement analysis and ratio analysis using Excel; Bloomberg Market Concepts completed"])],
     ["MBA (Finance), NMIMS Mumbai, 2023 - 2025 (pursuing)", "B.Com, Fergusson College, 2020 - 2023"],
     "Financial Modelling, DCF, Valuation, Financial Statement Analysis, Advanced Excel, Python, Communication, Teamwork",
     ["Bloomberg Market Concepts", "NISM Series VIII"], True),

    ("Divya Reddy", "Hyderabad", "standard",
     "FP&A analyst who blends finance and analytics; 4 years of experience in business partnering and reporting automation.",
     [("Financial Analyst - FP&A", "Lumina Software Solutions", "Jan 2022 - Present",
       ["Budgeting, forecasting and variance analysis for a $60M SaaS business unit",
        "Financial modelling and scenario analysis for pricing and headcount planning",
        "Built Power BI and Tableau dashboards on SQL data marts; automated monthly MIS reporting with Python and VBA",
        "Advanced Excel (pivot tables, power query, xlookup) and SAP; stakeholder management with product and sales leaders"]),
      ("Finance Associate", "Lumina Software Solutions", "Jun 2020 - Dec 2021",
       ["Accounting, reconciliation and financial statement analysis; month-end close support"])],
     ["MBA (Finance & Analytics), ISB Hyderabad, 2020", "B.Tech (Computer Science), JNTU, 2018"],
     "FP&A, Financial Modelling, Budgeting, Variance Analysis, Advanced Excel, VBA, SQL, Python, Power BI, Tableau, SAP, MIS Reporting, Stakeholder Management",
     ["CFA Level I passed"], False),

    ("Rohit Kapoor", "Noida", "standard",
     "Software developer with 4 years of experience building web applications and data pipelines.",
     [("Software Engineer", "Pixelwave Technologies", "Jun 2022 - Present",
       ["Developed REST APIs and microservices in Python and Java; SQL database design",
        "Built machine learning models for churn prediction and NLP-based chatbots",
        "Automation of deployment pipelines; agile teamwork and problem solving"]),
      ("Junior Developer", "Pixelwave Technologies", "Jul 2020 - May 2022",
       ["Front-end development in JavaScript and React; unit testing"])],
     ["B.Tech (Computer Science), NIT Warangal, 2020"],
     "Python, Java, JavaScript, SQL, Machine Learning, NLP, Teamwork, Problem Solving, Data Analysis",
     [], False),

    ("Neha Bansal", "Delhi", "standard",
     "Marketing executive with 3 years of experience in brand campaigns and social media.",
     [("Marketing Executive", "BrightLeaf Consumer Goods", "Mar 2023 - Present",
       ["Planned digital campaigns, managed budgets of Rs 40 lakh and reported ROI to the brand head",
        "Presentation decks in PowerPoint; strong communication and stakeholder management with agencies"]),
      ("Marketing Trainee", "BrightLeaf Consumer Goods", "Jul 2022 - Feb 2023",
       ["Market research, competitor analysis and data analysis in Excel"])],
     ["MBA (Marketing), NMIMS Mumbai, 2022", "BBA, Christ University, 2020"],
     "Digital Marketing, Brand Management, Advanced Excel, PowerPoint, Communication, Stakeholder Management, Teamwork",
     [], False),

    ("Aditya Rao", "Bengaluru", "standard",
     "Banking professional with 7 years of experience in corporate banking, credit appraisal and loan underwriting.",
     [("Relationship Manager - Corporate Banking", "Union Trust Bank", "May 2019 - Present",
       ["Manage a portfolio of 35 mid-corporate clients; credit analysis, credit appraisal and loan underwriting",
        "Structure working capital and term loans; trade finance (letters of credit, bank guarantees) and cash management solutions",
        "Financial statement analysis and ratio analysis for credit memos; risk assessment and compliance with RBI norms",
        "Cross-selling of treasury and forex products; client management and stakeholder engagement"]),
      ("Credit Officer", "Union Trust Bank", "Jun 2016 - Apr 2019",
       ["Retail and SME loan processing, KYC and AML checks, credit scoring"])],
     ["MBA (Banking & Finance), NMIMS Mumbai, 2016", "B.Com, Bangalore University, 2014"],
     "Corporate Banking, Credit Analysis, Loan Underwriting, Trade Finance, Treasury, Risk Management, Ratio Analysis, KYC, AML, Advanced Excel, Stakeholder Management",
     ["CAIIB"], True),

    ("Sara Thomas", "Bengaluru", "alt",
     "ACCA-qualified financial accountant with 6 years of experience in IFRS reporting, consolidation and audit support.",
     [("Assistant Manager - Financial Reporting", "Global Tech Services India", "Oct 2020 - Present",
       ["Month-end close, consolidation and group reporting under IFRS and Ind AS for 6 subsidiaries",
        "Account reconciliation, general ledger review and intercompany eliminations in SAP and Oracle Financials",
        "Coordinate external statutory audit and internal audit queries; SOX controls testing",
        "Advanced Excel and Power BI for management reporting"]),
      ("Senior Accountant", "Prism Audit Partners LLP", "Jun 2018 - Sep 2020",
       ["Statutory audit assurance, accounting and taxation support for listed clients"])],
     ["ACCA (Association of Chartered Certified Accountants), 2018", "B.Com, Mount Carmel College, 2016"],
     "IFRS, Ind AS, Accounting, Consolidation, Month-end close, Reconciliation, SAP, Oracle Financials, Advanced Excel, Power BI, SOX, Internal Controls",
     ["ACCA"], False),

    ("Manish Gupta", "Jaipur", "standard",
     "Equity trader and technical analyst with 3 years of experience in Indian equity and derivatives markets.",
     [("Equity Dealer", "Quickstep Broking Pvt Ltd", "Jan 2023 - Present",
       ["Execute equity trading and F&O strategies for HNI clients; technical analysis using candlestick and chart patterns",
        "Risk management and margin monitoring; prepare daily market reports"]),
      ("Research Trainee", "Quickstep Broking Pvt Ltd", "Jul 2022 - Dec 2022",
       ["Technical analysis and fundamental analysis notes for retail investors"])],
     ["B.Com, Rajasthan University, 2022"],
     "Equity Trading, Technical Analysis, Derivatives, F&O, Fundamental Analysis, Risk Management, Advanced Excel, Communication",
     ["NISM Series VIII"], False),

    ("Kavya Menon", "Mumbai", "alt",
     "Private equity and M&A associate with 2 years of experience in deal sourcing, valuation and due diligence.",
     [("Associate - Private Equity", "Evergreen Growth Partners", "07/2024 - Present",
       ["Deal sourcing, screening and preparation of investment memos and term sheet analysis",
        "Financial modelling, DCF valuation and LBO modelling for growth equity investments",
        "Comparable company analysis using Capital IQ and Refinitiv; M&A due diligence coordination",
        "Prepared pitch books and board presentations in PowerPoint"]),
      ("Analyst - M&A Advisory", "Blueridge Advisory", "07/2022 - 06/2024",
       ["Built trading comps and precedent transactions databases; CIM and teaser drafting"])],
     ["MBA (Finance), IIM Bangalore, 2022", "B.Com, Loyola College, 2020"],
     "Private Equity, M&A, Financial Modelling, DCF, LBO, Comparable Company Analysis, Capital IQ, Refinitiv, Pitch Books, PowerPoint, Advanced Excel",
     ["Financial Modeling & Valuation Analyst (FMVA)"], False),

    ("Imran Sheikh", "Mumbai", "noheads",
     "Treasury and trade finance professional, 5 years of experience.",
     [("Assistant Manager - Treasury", "Sapphire Exports Ltd", "Apr 2021 - Present",
       ["Liquidity management, cash flow forecasting and working capital management for a Rs 1,200 Cr exporter",
        "Trade finance operations: letters of credit, bank guarantees and forex hedging with derivatives",
        "Prepare treasury MIS reports and variance analysis; bank relationship management"]),
      ("Executive - Trade Finance", "Sapphire Exports Ltd", "Jun 2019 - Mar 2021",
       ["Documentary credit processing, accounts receivable follow-ups and reconciliation"])],
     ["MBA (Finance), Welingkar Institute, 2019", "B.Com, HR College, 2017"],
     "Treasury Management, Trade Finance, Cash Flow Management, Derivatives, Forex, Advanced Excel, MIS Reporting, Risk Management",
     [], False),

    ("James Carter", "Singapore", "standard",
     "CPA with 8 years of experience in financial planning and analysis and US GAAP reporting for multinational corporations.",
     [("Finance Manager - FP&A", "Atlas Global Logistics", "Jan 2019 - Present",
       ["Lead annual budgeting, forecasting and variance analysis across APAC; manage a team of 3 analysts",
        "Financial modelling, financial statement analysis and scenario analysis for board reviews",
        "US GAAP and IFRS reporting, month-end close and consolidation; SAP, Hyperion and advanced Excel with VBA",
        "Stakeholder management with regional CFOs; Tableau dashboards"]),
      ("Senior Financial Analyst", "Atlas Global Logistics", "Mar 2016 - Dec 2018",
       ["Forecasting, ratio analysis, cost accounting and management reporting"])],
     ["MBA, National University of Singapore, 2016", "B.Acc, Nanyang Technological University, 2013"],
     "FP&A, Financial Modelling, Budgeting, Forecasting, Variance Analysis, US GAAP, IFRS, Consolidation, SAP, Hyperion, Advanced Excel, VBA, Tableau, Leadership",
     ["CPA"], False),

    ("Tanvi Shah", "Mumbai", "standard",
     "Data-driven finance professional using machine learning for credit scoring and risk analytics; 3 years of experience.",
     [("Risk Analytics Analyst", "Finora Fintech Lending", "Aug 2023 - Present",
       ["Built credit scoring and probability of default models in Python (scikit-learn) on loan performance data",
        "Credit risk monitoring dashboards in Power BI; SQL data extraction; stress testing of the lending portfolio",
        "Ratio analysis and financial statement analysis for SME borrowers; regulatory reporting and Basel norms awareness"]),
      ("Data Analyst", "Finora Fintech Lending", "Jul 2022 - Jul 2023",
       ["Data analysis and data visualization for collections and loan origination teams"])],
     ["MBA (Business Analytics & Finance), NMIMS Mumbai, 2022", "B.Sc (Statistics), Mumbai University, 2020"],
     "Credit Risk, Machine Learning, Python, SQL, Power BI, Stress Testing, Ratio Analysis, Financial Statement Analysis, Risk Management, Data Analysis",
     ["FRM Part I"], True),
]


# ------------------------------------------------------------------ text layouts ------------------------------------------------------------------ #
def _headings(style):
    if style == "alt":
        return dict(summary="Profile", exp="Professional Experience", edu="Education", skills="Key Skills", cert="Certifications")
    if style == "noheads":
        return None
    return dict(summary="PROFESSIONAL SUMMARY", exp="WORK EXPERIENCE", edu="EDUCATION", skills="SKILLS", cert="CERTIFICATIONS")


def render_text(c, idx):
    name, city, style, summary, jobs, edu, skills, certs, _ = c
    handle = name.lower().replace(" ", ".")
    lines = [name, f"{city} | {handle}@examplemail.com | +91 9{800000000 + idx * 1234567 % 199999999:09d}", ""]
    h = _headings(style)
    if h:
        lines += [h["summary"], summary, "", h["exp"]]
    else:
        lines += [summary, ""]
    for title, company, dates, bullets in jobs:
        lines.append(f"{title}, {company} ({_shift(dates)})")
        lines += [f"- {b}" for b in bullets]
        lines.append("")
    if h:
        lines += [h["edu"]] + [f"- {_shift(e)}" for e in edu] + ["", h["skills"], skills, ""]
        if certs:
            lines += [h["cert"]] + [f"- {x}" for x in certs]
    else:
        lines += ["Education: " + _shift("; ".join(edu)), "Skills: " + skills]
        if certs:
            lines.append("Certifications: " + "; ".join(certs))
    return "\n".join(lines)


def write_pdf(path, text):
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
    from xml.sax.saxutils import escape

    styles = getSampleStyleSheet()
    body = ParagraphStyle("body", parent=styles["Normal"], fontSize=10, leading=13)
    head = ParagraphStyle("head", parent=styles["Heading3"], spaceBefore=8, spaceAfter=2)
    title = ParagraphStyle("title", parent=styles["Title"], fontSize=18, alignment=0)
    doc = SimpleDocTemplate(str(path), pagesize=A4, leftMargin=48, rightMargin=48, topMargin=42, bottomMargin=42)
    story = []
    for n, line in enumerate(text.splitlines()):
        if n == 0:
            story.append(Paragraph(escape(line), title))
        elif not line.strip():
            story.append(Spacer(1, 4))
        elif line.isupper() or line in {"Profile", "Professional Experience", "Education", "Key Skills", "Certifications"}:
            story.append(Paragraph(escape(line), head))
        else:
            story.append(Paragraph(escape(line), body))
    doc.build(story)


def main():
    OUT.mkdir(exist_ok=True)
    for old in OUT.glob("*"):
        old.unlink()
    for idx, c in enumerate(CANDIDATES, start=1):
        text = render_text(c, idx)
        stem = c[0].lower().replace(" ", "_") + "_resume"
        if c[-1]:
            try:
                write_pdf(OUT / f"{stem}.pdf", text)
                continue
            except ImportError:
                print("reportlab not installed - writing .txt instead of .pdf for", c[0])
        (OUT / f"{stem}.txt").write_text(text, encoding="utf-8")
    print(f"Created {len(list(OUT.glob('*')))} sample resumes in {OUT}")


if __name__ == "__main__":
    main()
